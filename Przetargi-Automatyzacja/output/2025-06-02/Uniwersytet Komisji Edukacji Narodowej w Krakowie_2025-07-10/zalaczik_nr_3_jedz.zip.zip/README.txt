Oto kr�tka dokumentacja plik�w ESPD, kt�r� znajd� Pa�stwo w tym folderze ZIP.

espd.XML: Plik XML to plik, kt�re mo�e zosta� odczytany przez nasz serwis ESPD lub inne kompatybilne serwisy ESPD. Zaleta korzystania z eESPD jako pliku XML polega na tym, �e nabywcy i przedsi�biorstwa mog� wykorzysta� go ponownie do cel�w innych post�powa� w przysz�o�ci. Nale�y przesy�a� go razem z dokumentami zam�wienia (od zamawiaj�cego do przedsi�biorstw) lub w ramach oferty (od przedsi�biorstw do zamawiaj�cego).

espd.PDF: Plik PDF to plik eESPD w postaci czytelnej dla cz�owieka. Proponujemy r�wnie� w tym miejscu, aby wykorzystywa� go obok formatu XML przy dokumentach zam�wienia (od zamawiaj�cego do przedsi�biorstw) lub w ramach oferty (od przedsi�biorstw do zamawiaj�cego) jako dokument referencyjny.

Je�eli maj� Pa�stwo pytania dotycz�ce plik�w, prosimy o kontaktowanie si� z nami za po�rednictwem nast�puj�cego adresu e-mail: grow-espd@ec.europa.eu.